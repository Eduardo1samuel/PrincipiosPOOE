package TareasEntregables_PrincipiosDePoo;

public class EstudianteYaInscritoException extends Exception {
    public EstudianteYaInscritoException(String message) {
        super(message);
    }
}

