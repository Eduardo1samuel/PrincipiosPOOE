package TareasEntregables_PrincipiosDePoo;

public class EstudianteNoInscritoEnCursoException extends Exception {
    public EstudianteNoInscritoEnCursoException(String message) {
        super(message);
    }
}
